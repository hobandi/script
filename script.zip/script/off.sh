#!/bin/sh
sudo mkdir -p /opt/cisco/anyconnect/profile/folder/ && sudo cp /opt/cisco/anyconnect/profile/POC-ExtendedUser.xml $_
sudo rm /opt/cisco/anyconnect/profile/POC-ExtendedUser.xml
sudo launchctl kickstart -kp system/com.cisco.anyconnect.vpnagentd
