#!/bin/sh
sudo cp /opt/cisco/anyconnect/profile/folder/POC-ExtendedUser.xml /opt/cisco/anyconnect/profile/
sudo rm -r /opt/cisco/anyconnect/profile/folder/